#include<cstdio>
#include<algorithm>
#include<map>
#include<vector>
#include<algorithm>
#include<iostream>
#include<queue>
#define MP make_pair
#define PB push_back
#define f first
#define s second
#define PII pair<int,int>
#define ALL(V) V.begin(),V.end()
#define LL long long
using namespace std;
int n,m,a,b,c,d;
LL l=31;
char ch;
vector<vector<char> > V;
int t[5000004];
int pom[5000004];
int okres(int N)
{
int w=0;
for(int i=1;i<N;i++)
	{
	while(w>0&&t[w]!=t[i])w=pom[w-1];
	if(t[w]==t[i])w++;
	pom[i]=w;
	}
while(N%(N-w)!=0)w=pom[w-1];
return N-w;
}
void solve()
{

scanf("%d%d",&n,&m);
for(int i=0;i<n;i++)
	{
	vector<char> X;
	for(int j=0;j<m;j++)
		{
		ch=0;
		while(ch<33)ch=getchar_unlocked();
		X.PB(ch);
		ch=ch-'A'+1;
		t[j]=((LL)t[j]*l+ch);
		}
	V.PB(X);
	}
int m1=okres(m);

for(int i=0;i<=m;i++)t[i]=0;

for(int i=0;i<n;i++)
	{
	for(int j=0;j<m;j++)
		{
		ch=V[i][j];
		ch=ch-'A'+1;
		t[i]=((LL)t[i]*l+ch);
		}
	}

int n1=okres(n);
printf("%d %d\n",n1,m1);

for(int i=0;i<n1;i++)
	{
	for(int j=0;j<m1;j++)
		{
		putchar_unlocked(V[i][j]);
		
		}
	puts("");
	}
}
main()
{
solve();
}
