#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<unordered_map>
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<int>
#define LL long long
#define MP make_pair
#define LD long double
#define PB push_back
#define ALL(V) V.begin(),V.end()
using namespace std;
int n,a,b;
VI in,V;
int sum;
LL wyn=0;
void patrz(int i,int j)
{
//cout<<i<<" s "<<j<<endl;
if(j==V.size())return;
if(V[i]+sum<=V[j])return;
LL a=V[j]-V[i];
LL b=sum-a;
wyn=max(wyn,a*b);

}
main()
{
scanf("%d",&n);
for(int i=0;i<n;i++)
  {
  scanf("%d",&a);
  sum+=a;
  in.PB(a);
  }
for(int i=0;i<n;i++)
  {
  in.PB(in[i]);
  }
for(int i=1;i<in.size();i++)in[i]+=in[i-1];

if(sum%2==1)
  {
  puts("0");
  return 0;
  }
sum/=2;
int w=0;
in.PB(2e9+10);
for(int i=0;i<n;i++)
  {
  while(in[i]>in[w]-sum)w++;
  if(in[i]==in[w]-sum)V.PB(in[i]);
  }
w=0;
a=V.size();

for(int i=0;i<a;i++)
  {
 // cout<<i<<" "<<V[i]<<endl;
  V.PB(V[i]+sum*2);
  }
V.PB(2e9+10);
for(int i=0;i<a;i++)
  {
  while(V[i]+sum/2>V[w])w++;

  patrz(i,w);
  patrz(i,w-1);
  }
printf("%lld\n",wyn);
}