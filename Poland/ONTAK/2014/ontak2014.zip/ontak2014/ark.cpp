#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
#include<tr1/unordered_map>
#include<queue>
#include<cstdlib>
#include<list>
#include<set>
#include<map>
#include<cmath>
#define MP make_pair
#define PB push_back
#define s second
#define f first
#define PII pair<int,int>
#define VPII vector< PII > 
#define VI vector <int>
#define abs(a) max((a),-(a))
#define LL long long
#define LD long double
#define ALL(x) x.begin(),x.end()
#define PU putchar_unlocked
#define GU getchar_unlocked
using namespace std;
int a,b,c,d,e,f,n,m,mx,l,z,r,k;
int dp[301][301][301];
int sum[302][302][302];
int t[304];
PII R[304];
int MOD=1e9+33;
int x(int i,int a,int b,int u)
{
return (((b<0)?0:sum[i][b][u])-(((a-1)<0)?0:sum[i][a-1][u]))%MOD;
}
void licz(int i,int j,int u)
{
dp[i][j][u]+=dp[i-1][j][u];//nie biore nic z i
if(j>R[i].s||j<R[i].f)return;

if(i==j)dp[i][j][u]=(dp[i][j][u]+dp[i-1][j-1][u])%MOD;
if(u==0)return;

dp[i][j][u]=(dp[i][j][u]+x(i-1,R[i].f-1,j-2,u-1))%MOD;

if(i!=j)dp[i][j][u]=(dp[i][j][u]+dp[i-1][j-1][u-1])%MOD;

}
void solve()
{
scanf("%d%d",&n,&k);
for(int i=1;i<=n;i++)
	{
	scanf("%d",&t[i]);
	}
for(int i=1;i<=n;i++)
	{
	R[i]=MP(1,n);
	for(int j=i;j>=1;j--)
		if(t[j]<t[i])
			{
			R[i].f=j+1;
			break;
			}
	
	for(int j=i;j<=n;j++)
		if(t[j]<t[i])
			{
			R[i].s=j-1;
			break;
			}
	}
for(int i=0;i<=n;i++)
	{
	dp[i][0][0]=sum[i][0][0]=1;
	for(int j=1;j<=n;j++)
		sum[i][j][0]=sum[i][j-1][0]+dp[i][j][0];
	}	
for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
		for(int u=0;u<=k;u++)
			{
			licz(i,j,u);
	//		cout<<i<<" "<<j<<" "<<u<<" "<<dp[i][j][u]<<endl;
			sum[i][j][u]=(sum[i][j-1][u]+dp[i][j][u])%MOD;
			}
LL res=0;

for(int i=0;i<=k;i++)
		res+=dp[n][n][i];
cout<<(res%MOD+MOD)%MOD<<endl;
}
int main()
{
solve();
}
