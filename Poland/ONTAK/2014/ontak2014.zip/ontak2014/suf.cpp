#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<unordered_map>
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<int>
#define LL long long
#define MP make_pair
#define LD long double
#define PB push_back
#define ALL(V) V.begin(),V.end()
using namespace std;
int n,a,b,w,s,k,c,d,e;
int t[1000004];
int x[1000005];
int wyn[1000004];
main()
{
scanf("%d",&n);
t[n+1]=n+1;
for(int i=1;i<=n;i++)
  {
  scanf("%d",&t[i]);
  x[t[i]]=i;
  }
  
int pop=0;
int id=1;
for(int i=1;i<=n;i++)
  {
  if(t[x[i]+1]<pop)id++;
  wyn[x[i]]=id;
  pop=t[x[i]+1];
  }
for(int i=1;i<=n;i++)printf("%d ",wyn[i]);
}