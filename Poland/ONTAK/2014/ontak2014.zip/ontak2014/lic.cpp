#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<unordered_map>
#define PII pair<int,int>
#define f first
#define s second
#define LL long long
#define VI vector<int>
#define VL vector<LL>

#define MP make_pair
#define LD long double
#define PB push_back
#define ALL(V) V.begin(),V.end()
using namespace std;
int n,a,b,k,m;
int wielkosc[1000004];
const int MXSIZ=40;
int takiejwielkosci[MXSIZ];
int dp[MXSIZ+1][103];//ile mozliwosci z grupy o wielkosci i wziecia j roznych
LL mozl[202][2];
VL res;
vector<LL> lacz(vector<LL>  a,vector<LL>  b)
{
vector< LL>  res;
res.resize(k+1);
for(int i=0;i<a.size();i++)
  {
  for(int j=0;j<b.size();j++)
    {
    if(i+j>k)continue;
    res[i+j]+=a[i]*b[j];
    res[i+j]%=m;
    }
  }
return res;
}
VL pow(VL V,int n)
{
if(n==1)return V;
if(n%2==0)
  {
  VL x=pow(V,n/2);
  return lacz(x,x);
  }
else
  {
  VL x=pow(V,n-1);
  return lacz(x,V);
  }
}

int ile(int i)
{
int a=0;
for(int j=i;j<=n;j*=2)
    {
    a++;
    }
return a;
}
main()
{
scanf("%d%d%d",&n,&k,&m);
int mxwie=ile(1);;
int teraz=ile(1);
for(int i=1;i<=n;i++)
  {
  int poc=i;
  int kon=n;
  int sr=-1;
  while(sr!=(poc+kon)/2)
    {
    sr=(poc+kon)/2;
    if(ile(sr)==teraz)poc=sr;
    else kon=sr;
    }
  while(sr<n&&ile(sr+1)==teraz)sr++;
  while(sr>=i&&ile(sr)!=teraz)sr--;
  takiejwielkosci[teraz]=(sr-i+1)/2;
  //cout<<i<<" d "<<sr<<endl;
  if(i%2==1&&(sr-i+1)%2==1)takiejwielkosci[teraz]++;
  i=sr;
  teraz--;
 // printf("%d %d\n",teraz+1,takiejwielkosci[teraz+1]);
  }


dp[0][0]=1;
for(int i=0;i<MXSIZ;i++)dp[i][1]=i;
for(int i=0;i<MXSIZ;i++)dp[i][0]=1;
for(int j=2;j<=k;j++)
  {
  for(int i=1;i<=mxwie;i++)
    {
    for(int u=0;u<i-1;u++)
      {
      dp[i][j]+=dp[u][j-1];
      dp[i][j]%=m;
      }
   // cout<<i<<" "<<j<<" "<<dp[i][j]<<endl;
    }
  }
res.resize(k+1);
res[0]=1;
VL pom;
pom.resize(k+1);
for(int i=1;i<=mxwie;i++)
  {
  if(takiejwielkosci[i]==0)continue;
  for(int j=0;j<=k;j++)
    {
    pom[j]=dp[i][j];
    }
  pom=pow(pom,takiejwielkosci[i]);
  res=lacz(res,pom);
  }  
cout<<res[k]<<endl;


}