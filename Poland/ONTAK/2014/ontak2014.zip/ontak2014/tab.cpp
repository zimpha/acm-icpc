#include<cstdio>
#include<algorithm>
using namespace std;

int main()
{
	int n, k;
	scanf("%d%d", &n, &k);
	if(k<n) 
	{
		printf("NIE\n");
		return 0;
	}
	printf("TAK\n");
	for(int i=0; i<n; i++)
	{
		for(int j=0; j<n; j++)
		{
			if(i==j) printf("%d ", k-n+1);
			else printf("1 ");
		}
		printf("\n");
	}
}
