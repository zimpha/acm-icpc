#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<cmath>
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<LL>
#define LL long long
#define MP make_pair
#define LD long double
#define PB push_back
#define ALL(V) V.begin(),V.end()
#define size(V) ((int)V.size())
using namespace std;
LL n,a,b,w,s,k,c,d,e,z;
const LL MXN=1e18;
VI V[4];

void solve()
{
scanf("%lld%lld",&n,&k);
for(int i=0;i<size(V[k]);i++)
  {
  if(V[k][i]==n)
    {
    puts("R");
    return;
    }
  }
puts("C");
}
void gen(VI &poc,LL pop)
{
while(poc.back()<=MXN)
  {
  poc.PB(poc.back()+poc[size(poc)-pop]);
  }

}
main()
{

V[1]={1,2};
gen(V[1],1);

V[2]={1,2,3,5};
gen(V[2],2);

V[3]={1,2,3,4,6,8};
gen(V[3],4);

//cout<<size(k1)<<" "<<size(k2)<<" "<<size(k3)<<endl;
scanf("%lld",&z);
while(z--)solve();
}
