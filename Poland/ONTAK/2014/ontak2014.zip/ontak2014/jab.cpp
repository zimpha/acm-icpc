#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<queue>
#include<tr1/unordered_map>
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<int>
#define LL long long 
#define MP make_pair
#define LD long double
#define PB push_back
#define ALL(V) V.begin(),V.end()
using namespace std;
int n,a,b,c,d,s,w,k;
char ch;
const int MA=82,MB=802;
vector< pair< PII , int > > V[MA][MB];
vector< pair< PII , int > > X[MA][MB];

int SZER=11;
int odl[MA][MB];
int odl2[MA][MB];
bool z[MA][MB];
priority_queue< pair < int , PII > , vector< pair < int, PII >  >, greater < pair < int,PII > > > q;
void dijksra(int x,int y,int poc,int kon)
{
for(int i=1;i<=w;i++)
   {
   for(int j=poc;j<=kon;j++)
      {
      odl2[i][j]=2000000000;
      z[i][j]=0;
      }
   }
odl2[x][y]=0;
q.push(MP(0,MP(x,y)));
while(q.size())
   {
   x=q.top().s.f;
   y=q.top().s.s;
   q.pop();
   if(z[x][y])continue;
   z[x][y]=1;
   for(int i=0;i<V[x][y].size();i++)
      {
      a=V[x][y][i].f.f;
      b=V[x][y][i].f.s;
      c=V[x][y][i].s;

      if(b<poc||kon<b)continue;
      if(odl2[x][y]+c<odl2[a][b])
         {
         odl2[a][b]=odl2[x][y]+c;
         q.push(MP(odl2[a][b],MP(a,b)));
         }
      }
   }
}
void bell(int x,int y,int poc,int kon)
{

for(int i=1;i<=w;i++)
      {
   for(int j=poc;j<=kon;j++)
      {
      odl[i][j]=1400000000;
      }
   }
odl[x][y]=0;
while(1)
   {
   bool x=0;

   for(int i=1;i<=w;i++)
      {
      for(int j=poc;j<=kon;j++)
         {
         for(int u=0;u<V[i][j].size();u++)
            {
            a=V[i][j][u].f.f;
            b=V[i][j][u].f.s;
            c=V[i][j][u].s;
            if(b<poc||kon<b)continue;
            if(odl[i][j]+c<odl[a][b])
               {
       //        printf("%d %d %d\n",a,b,odl[a][b]);
               odl[a][b]=odl[i][j]+c;
               x=1;
               }
            }
         }
       }
   if(x==0)break;
   }
}
void licz(int poc,int kon)
{
bell(1,poc,poc,kon);

for(int i=1;i<=w;i++)
   {
   for(int j=poc;j<=kon;j++)
      {
      for(int u=0;u<V[i][j].size();u++)
         {
         a=V[i][j][u].f.f;
         b=V[i][j][u].f.s;
         c=V[i][j][u].s;
         if(b<poc&&kon<b)continue;
         V[i][j][u].s+=odl[i][j]-odl[a][b];
         }
      }
    }

for(int i=1;i<=w;i++)
   {
   for(int j=poc;j<=kon;j+=kon-poc)
      {
      dijksra(i,j,poc,kon);
      for(int i1=1;i1<=w;i1++)
         {
         for(int j1=poc;j1<=kon;j1+=kon-poc)
            {
            LL c=(LL)odl2[i1][j1]-odl[i][j]+odl[i1][j1];
            if(c>700000000)continue;
            X[i][j].PB(MP(MP(i1,j1),c));
            }
         }
      }
   }
  // dijksra(2,1,poc,kon);
for(int i=1;i<=w;i++)
   {
   for(int j=poc;j<=kon;j++)
      {
      for(int u=0;u<V[i][j].size();u++)
         {
         a=V[i][j][u].f.f;
         b=V[i][j][u].f.s;
         c=V[i][j][u].s;
         if(b<poc&&kon<b)continue;
         V[i][j][u].s-=odl[i][j]-odl[a][b];
         }
      }
    }
}
void bell2()
{

for(int i=1;i<=w;i++)
      {
   for(int j=1;j<=s;j++)
      {
      odl[i][j]=1400000000;
      }
   }
odl[1][1]=0;
while(1)
   {
   bool x=0;

   for(int i=1;i<=w;i++)
      {
      for(int j=1;j<=s;j++)
         {
         for(int u=0;u<X[i][j].size();u++)
            {
            a=X[i][j][u].f.f;
            b=X[i][j][u].f.s;
            c=X[i][j][u].s;
            if(odl[i][j]+c<odl[a][b])
               {
               odl[a][b]=odl[i][j]+c;
               x=1;
               }
            }
         }
       }
   if(x==0)break;
   }
while(1)
   {
   bool x=0;

   for(int i=1;i<=w;i++)
      {
      for(int j=1;j<=s;j++)
         {
         for(int u=0;u<V[i][j].size();u++)
            {
            a=V[i][j][u].f.f;
            b=V[i][j][u].f.s;
            c=V[i][j][u].s;
            if(odl[i][j]+c<odl[a][b])
               {
               odl[a][b]=odl[i][j]+c;
               x=1;
               }
            }
         }
       }
   if(x==0)break;
   }
}


void solve()
{
scanf("%d%d%d",&w,&s,&k);
for(int i=1;i<=k;i++)
   {
   scanf("%d%d %c%d",&a,&b,&ch,&c);
   swap(a,b);
   if(ch=='N')V[a][b].PB(MP(MP(a+1,b),c));
   if(ch=='S')V[a][b].PB(MP(MP(a-1,b),c));
   if(ch=='W')V[a][b].PB(MP(MP(a,b-1),c));
   if(ch=='E')V[a][b].PB(MP(MP(a,b+1),c));
   }
int a=1;
while(1)
   {
   licz(a,min(s,a+SZER));
   a+=SZER;
   if(a>=s)break;
   }


bell2();
for(int i=1;i<=w;i++)
   {
   for(int j=1;j<=s;j++)
      {
      if(odl[i][j]>700000000)
         {
         printf("N ");
         }
      else
         {
         printf("%d ",odl[i][j]);
         }
      }puts("");
   }
}
main()
{
solve();
}
