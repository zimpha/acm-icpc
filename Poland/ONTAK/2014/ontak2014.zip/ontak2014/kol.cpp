#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<unordered_map>
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<int>
#define LL long long
#define MP make_pair
#define LD long double
#define PB push_back
#define ALL(V) V.begin(),V.end()
using namespace std;
#include "kol.h"

int n,a,b;
int jakagrupa[5004];
VI czlonkowie[5004];
VI V[5004];
main()
{
srand(1);
init();
int grup=10;
int n=5000;
VI pok;
for(int i=0;i<n;i++)
  {
  jakagrupa[i]=rand()%grup;
  czlonkowie[jakagrupa[i]].PB(i);
  pok.PB(jakagrupa[i]);
  }
int krawedzie=300000;
for(int i=1;i<=krawedzie;i++)
  {
  a=b=1;
  while(jakagrupa[a]==jakagrupa[b])
    {
    a=rand()%n;
    b=rand()%n;
    }
  if(b<a)swap(a,b);
  V[b].PB(a);
  }
for(int i=0;i<n;i++)
  {
  create(V[i]);
  }
answer(pok);
}