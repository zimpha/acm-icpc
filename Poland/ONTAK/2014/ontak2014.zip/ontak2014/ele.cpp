#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<unordered_map>
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<int>
#define LL long long
#define MP make_pair
#define LD long double
#define PB push_back
#define ALL(V) V.begin(),V.end()
using namespace std;
int n,a,b;
const int MXN=5e5+10;
LL pod[MXN];//maksymalna suma na takiej parze ktora jest pod lub zachacza o ten wierzchoek
LL odl[MXN];//masymalna odlego w dol
LL podnaj[MXN];//maksymalna suma taka ze jest jedna para skonczona pod i jedna sciezka do tego
//wierzcholka, sciezki sa rozlaczne
VI V[MXN];
LL cost[MXN];//koszt dosjcia do ojca
LL sum;//suma krawiedzi
void dfswagi(int a,int pop);
LL wyn;
void dfs(int a,int pop)
{
pair<LL,int> naj1,naj2,naj3;
naj1=naj2=naj3=MP(0,0);

pair<LL,int> pod1,pod2,pod3;
pod1=pod2=pod3=MP(0,0);

pair<LL,int> podnaj1,podnaj2;
podnaj1=podnaj2=MP(0,0);

pod[a]=odl[a]=podnaj[a]=0;

for(int i=0;i<V[a].size();i++)
  {
  if(V[a][i]==pop)continue;
  dfs(V[a][i],a);
  odl[a]=max(odl[a],odl[V[a][i]]+cost[V[a][i]]);
  
  if(naj1<MP(odl[V[a][i]]+cost[V[a][i]],V[a][i]))
    {
    naj3=naj2;
    naj2=naj1;
    naj1=MP(odl[V[a][i]]+cost[V[a][i]],V[a][i]);
    }
  else
    {
    if(naj2<MP(odl[V[a][i]]+cost[V[a][i]],V[a][i]))
      {
      naj3=naj2;
      naj2=MP(odl[V[a][i]]+cost[V[a][i]],V[a][i]);
      }
    else
      {
      if(naj3<MP(odl[V[a][i]]+cost[V[a][i]],V[a][i]))
        {
        naj3=MP(odl[V[a][i]]+cost[V[a][i]],V[a][i]);
        }
      }
    }

  pod[a]=max(pod[a],pod[V[a][i]]);

  if(pod1<MP(pod[V[a][i]],V[a][i]))
    {
    pod3=pod2;
    pod2=pod1;
    pod1=MP(pod[V[a][i]],V[a][i]);
    }
  else
    {
    if(pod2<MP(pod[V[a][i]],V[a][i]))
      {
      pod3=pod2;
      pod2=MP(pod[V[a][i]],V[a][i]);
      }
    else
      if(pod3<MP(pod[V[a][i]],V[a][i]))
        {
        pod3=MP(pod[V[a][i]],V[a][i]);
        }
    }  
  
  podnaj[a]=max(podnaj[a],podnaj[V[a][i]]+cost[V[a][i]]);
  
  if(podnaj1< MP(podnaj[V[a][i]]+cost[V[a][i]],V[a][i]))
    {
    podnaj2=podnaj1;
    podnaj1= MP(podnaj[V[a][i]]+cost[V[a][i]],V[a][i]);
    }
  else
    {
    if(podnaj2<MP(podnaj[V[a][i]]+cost[V[a][i]],V[a][i]))
      {
      podnaj2=MP(podnaj[V[a][i]]+cost[V[a][i]],V[a][i]);
      }
    
    }
  }
pod[a]=max(pod[a],naj1.f+naj2.f);
wyn=max(wyn,pod1.f+pod2.f);

  //podnaj+naj->wyn
if(podnaj1.s!=naj1.s)
  wyn=max(wyn,podnaj1.f+naj1.f);
if(podnaj2.s!=naj1.s)
  wyn=max(wyn,podnaj2.f+naj1.f);
if(podnaj1.s!=naj2.s)
  wyn=max(wyn,podnaj1.f+naj2.f);
if(podnaj2.s!=naj2.s)
  wyn=max(wyn,podnaj2.f+naj2.f);



      //naj+naj+pod->wyn
if(pod1.s!=naj1.s&&pod1.s!=naj2.s)
  wyn=max(wyn,pod1.f+naj1.f+naj2.f);
if(pod1.s!=naj1.s&&pod1.s!=naj3.s)
  wyn=max(wyn,pod1.f+naj1.f+naj3.f);
 if(pod1.s!=naj2.s&&pod1.s!=naj3.s)
  wyn=max(wyn,pod1.f+naj2.f+naj3.f);
 
if(pod2.s!=naj1.s&&pod2.s!=naj2.s)
  wyn=max(wyn,pod2.f+naj1.f+naj2.f);
if(pod2.s!=naj1.s&&pod2.s!=naj3.s)
  wyn=max(wyn,pod2.f+naj1.f+naj3.f);
 if(pod2.s!=naj2.s&&pod2.s!=naj3.s)
  wyn=max(wyn,pod2.f+naj2.f+naj3.f);
  
if(pod3.s!=naj1.s&&pod3.s!=naj2.s)
  wyn=max(wyn,pod3.f+naj1.f+naj2.f);
if(pod3.s!=naj1.s&&pod3.s!=naj3.s)
  wyn=max(wyn,pod3.f+naj1.f+naj3.f);
 if(pod3.s!=naj2.s&&pod3.s!=naj3.s)
  wyn=max(wyn,pod3.f+naj2.f+naj3.f);



  //pod+naj->podnaj
if(pod1.s!=naj1.s)
  podnaj[a]=max(podnaj[a],pod1.f+naj1.f);
if(pod1.s!=naj2.s)
  podnaj[a]=max(podnaj[a],pod1.f+naj2.f);
if(pod2.s!=naj1.s)
  podnaj[a]=max(podnaj[a],pod2.f+naj1.f);
if(pod2.s!=naj2.s)
  podnaj[a]=max(podnaj[a],pod2.f+naj2.f);



}
main()
{
scanf("%d",&n);
for(int i=1;i<n;i++)
  {
  scanf("%d%d",&a,&b);
  V[a].PB(b);
  V[b].PB(a);
  }
dfswagi(1,0);
dfs(1,0);
printf("%lld\n",sum-wyn);
}
int podd[MXN];
void dfswagi(int a,int pop)
  {
  podd[a]=0;
  for(int i=0;i<V[a].size();i++)
    {
    if(V[a][i]==pop)continue;
    dfswagi(V[a][i],a);
    podd[a]+=podd[V[a][i]];
    }
  podd[a]++;
  cost[a]=podd[a]*((LL)n-podd[a]);
  sum+=cost[a];
  }