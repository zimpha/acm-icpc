#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
#include<tr1/unordered_map>
#include<queue>
#include<cstdlib>
#include<list>
#include<set>
#include<map>
#include<cmath>
#define MP make_pair
#define PB push_back
#define s second
#define f first
#define PII pair<int,int>
#define VPII vector< PII > 
#define VI vector <int>
#define abs(a) max((a),-(a))
#define LL long long
#define LD long double
#define ALL(x) x.begin(),x.end()
#define PU putchar_unlocked
#define GU getchar_unlocked
#define size(V) ((int)V.size())
using namespace std;
int a,b,c,d,n,x;
void solve()
{
scanf("%d",&n);
VI V;
for(int i=1;i<=n;i++)
	{
	scanf(" %c",&a);
	if(a=='R')
		{
		V.PB(i);
		x^=i;
		}
	}
int res=0;
for(int i=0;i<size(V);i++)
	{
	if((x^V[i])<V[i])res++;
	}
printf("%d\n",res);
}
int main()
{
solve();
}