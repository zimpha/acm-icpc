#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<cmath>
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<int>
#define LL long long
#define MP make_pair
#define LD double
#define PB push_back
#define ALL(V) V.begin(),V.end()
#define abs(x) max((x),-(x))
#define PDD pair<LD,LD> 
#define VPII vector< PII > 
#define size(V) ((int)V.size())
using namespace std;
int n,a,b,w,s,k,c,d,e,Px,Py;
pair< LD, PDD > rownanie(PDD p1,PDD p2)
{
//cout<<p1.f<<" "<<p1.s<<" "<<p2.f<<" "<<p2.s<<" d "; 
if(p1.f==0)swap(p1,p2);
if(abs(p1.f-p2.f)<1e-10)return MP(1,PDD(0,-p1.f));

//cout<<p1.f<<" "<<p1.s<<" "<<p2.f<<" "<<p2.s<<" d "; 
LD c2=(p1.s*p2.f-p2.s*p1.f)/(p1.f-p2.f);
LD a2=(-c2-p1.s)/p1.f;



return MP(a2,PDD(1,c2));
}

LD od(LD A,LD B,LD C,LD x,LD y)
{
//printf("A: %0.5Lf B: %0.5Lf x: %0.5Lf y: %0.5Lf %0.5Lf\n",A,B,x,y,(A*x+B*y)/sqrt(A*A+B*B));
return abs((A*x+B*y+C)/sqrt((double)A*A+B*B));
}
LD ile(PDD p1,PDD p2,PDD p3)//odległosć prostej p1-p2 od punktu p3
{
pair< LD, PDD > x=rownanie(p1,p2);
//cout<<x.f<<" "<<x.s.f<<" "<<x.s.s<<endl;

return od(x.f,x.s.f,x.s.s,p3.f,p3.s);
}
LL det(LL a1,LL b1,LL a2,LL b2,LL a3,LL b3)
{
return (a1*b2+b1*a3+a2*b3)-(a3*b2+b3*a1+a2*b1);
}
bool strona(PII p1,PII p2,PII p3)
{
return det(p1.f,p1.s,p2.f,p2.s,p3.f,p3.s)>=0;
}

VPII convexhull(VPII in)
{
VPII ret;
sort(ALL(in));
for(int i=0;i<size(in);i++)
  {
  while(size(ret)>=2&&strona(ret[size(ret)-2],ret.back(),in[i]))ret.pop_back();
  ret.PB(in[i]);
  }
int a=size(ret);
for(int i=size(in)-1;i>=0;i--)
  {
  while(size(ret)>=a+1&&strona(ret[size(ret)-2],ret.back(),in[i]))ret.pop_back();
  ret.PB(in[i]);
  }
ret.pop_back();
return ret;
}
LD calcres(VPII points)
{
if(size(points)<3)return 0.0;
LD wyn=1e14;
int n=size(points);
for(int i=0;i<=n;i++)
  {
//  cout<<points[i].f<<" "<<points[i].s<<endl;
  points.PB(points[i]); 
  }
  
int w=2;
for(int i=0;i<n;i++)
  {
  while(ile(points[i],points[i+1],points[w])<=ile(points[i],points[i+1],points[w+1]))w++;
  wyn=min(wyn,ile(points[i],points[i+1],points[w]));
//  cout<<i<<" "<<w<<" "<<ile(points[i],points[i+1],points[w])<<endl;
  }
return wyn;
}
void solve()
{
scanf("%d%d%d",&n,&Px,&Py);
VPII points;

for(int i=1;i<=n;i++)
  {
  scanf("%d%d",&a,&b);
  a-=Px;
  b-=Py;
  points.PB(PII(a,b));
  points.PB(PII(-a,-b));
  }
points=convexhull(points);
LD res=calcres(points);
printf("%.6lf",res/2);
}
main()
{
solve();
}//719061.4237100
