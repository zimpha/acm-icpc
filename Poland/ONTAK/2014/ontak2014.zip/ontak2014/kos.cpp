#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<unordered_map>
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<int>
#define LL long long
#define MP make_pair
#define LD long double
#define PB push_back
#define ALL(V) V.begin(),V.end()
using namespace std;
int n,a,b,w,s,k,c,d,e;
VI dp[1003][2003];
int t[2][1004];
int MOD=1e9;
VI operator+(VI a,VI b)
{

while(a.size()<b.size())a.PB(0);
while(a.size()>b.size())b.PB(0);
a.PB(0);
b.PB(0);
int c=0;
for(int i=0;i<a.size();i++)
  {
  a[i]=a[i]+b[i]+c;
  c=a[i]/MOD;
  a[i]%=MOD;
  }
while(a.size()&&a.back()==0)a.pop_back();
return a;
}
void pisz(VI V)
{
while(V.size()&&V.back()==0)V.pop_back();
if(V.size()==0)
  {
  puts("0");
  return;
  }
printf("%d",V.back());
V.pop_back();
while(V.size())
  {
  printf("%0*d",9,V.back());
  V.pop_back();
  }
}
main()
{

scanf("%d",&n);
for(int i=0;i<2;i++)
  for(int j=1;j<=n;j++)
    scanf("%d",&t[i][j]);
int c;
for(int i=0;i<=n;i++)
  {
  if(t[0][i]!=i&&t[0][i]!=0)break;
  c=i;
  
  }
dp[0][0].PB(1);
for(int i=1;i<=n;i++)
  {
  dp[i%2][0].clear();
  if(c>=i)dp[i%2][0].PB(1);
  for(int j=1;j<=i;j++)
    {
    dp[i%2][j].clear();
    if(t[0][i]==0||t[0][i]==i+j)dp[i%2][j]=dp[i%2][j]+dp[(i-1)%2][j];
    if(t[1][j]==0||t[1][j]==i+j)dp[i%2][j]=dp[i%2][j]+dp[i%2][j-1];
    }
  }
pisz(dp[n%2][n]);


}