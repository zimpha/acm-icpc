#include<cstdio>
#include<algorithm>
#include<map>
#include<vector>
#define PB push_back
#define f first
#define s second
using namespace std;
int n,m;
int t[1004][1005];
int dp[1004][1004];
int mx[1004][1004];
void maxi(int &a,int b)
{
a=max(a,b);
}
void solve()
{
scanf("%d%d",&n,&m);
for(int i=1;i<=n;i++)
		{
		for(int j=1;j<=m;j++)
			{
			scanf("%d",&t[i][j]);	
			}
		}
for(int i=n;i>=1;i--)
	{
	for(int j=1;j<=m;j++)
		{
		dp[i][j]=mx[i+1][j-1]+t[i][j];
		maxi(mx[i][j],mx[i][j-1]);
		maxi(mx[i][j],dp[i][j]);
		maxi(mx[i][j],mx[i+1][j]);
		maxi(mx[i][j],mx[i+1][j-1]);
		}
	}
printf("%d\n",mx[1][m]);
}
int main()
{
solve();
}
