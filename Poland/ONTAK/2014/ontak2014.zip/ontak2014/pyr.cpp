#include<cstdio>
#include<algorithm>
#include<map>
#include<vector>
#include<algorithm>
#include<iostream>
#include<set>
#define MP make_pair
#define PB push_back
#define f first
#define s second
#define PII pair<int,int>
#define ALL(V) V.begin(),V.end()
#define VI vector<int>
using namespace std;
set< VI > S;
int res;
int n,a;
void go(VI V)
{
if(S.count(V))return;
S.insert(V);
res++;
VI V2;
for(int i=0;i<V.size();i++)
	{
	if(V[i]==-1)
		{
		V2=V;
		for(int j=0;j<V.size();j++)
			{
			if(V2[j]==i)
				{
				V2[j]=-1;
				}
			else
				{
				if(V2[j]==-1)
					{
					V2[j]=i;
					}
				}
			}
		go(V2);
		}
	}

}
void solve()
{
scanf("%d",&n);
if(n==1)
	{
	puts("1");
	return;
	}
VI V;
for(int i=1;i<=n;i++)
	{
	scanf("%d",&a);
	a--;
	V.PB(a);	
	}
go(V);
cout<<res<<endl;
}
int main()
{
solve();
}
