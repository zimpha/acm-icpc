#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
#include<tr1/unordered_map>
#include<queue>
#include<cstdlib>
#include<list>
#include<set>
#include<map>
#include<cmath>
#define MP make_pair
#define PB push_back
#define s second
#define f first
#define PII pair<int,int>
#define VPII vector< PII > 
#define VI vector <int>
#define abs(a) max((a),-(a))
#define LL long long
#define LD long double
#define ALL(x) x.begin(),x.end()
#define PU putchar_unlocked
#define GU getchar_unlocked
#define size(V) ((int)V.size())
using namespace std;
int n,m,a,b,c,d;
vector< pair< int, PII > > x,y;
int A,B;
bool check(int D)
{
int x1=-D;
int x2=D;
int y1=-D;
int y2=D;
int ok;
while(1)
  {
  ok=0;
  for(int i=0;i<size(x);i++)
    {
    if(x1<x[i].f&&x[i].f<x2&&((y1<x[i].s.f&&x[i].s.f<y2)||(y1<x[i].s.s&&x[i].s.s<y2)))
      {
      if(y1>min(x[i].s.f,x[i].s.s)-1)ok=1;
      y1=min(y1,min(x[i].s.f,x[i].s.s)-1);
      
      if(y2<max(x[i].s.f,x[i].s.s)+1)ok=1;
      y2=max(y2,max(x[i].s.f,x[i].s.s)+1);
      }
    }

  for(int i=0;i<size(y);i++)
    {
    if(y1<y[i].f&&y[i].f<y2&&((x1<y[i].s.f&&y[i].s.f<x2)||(x1<y[i].s.s&&y[i].s.s<x2)))
      {
      if(x1>min(y[i].s.f,y[i].s.s)-1)ok=1;
      x1=min(x1,min(y[i].s.f,y[i].s.s)-1);
      
      if(x2<max(y[i].s.f,y[i].s.s)+1)ok=1;
      x2=max(x2,max(y[i].s.f,y[i].s.s)+1);
      }
    }

  if(ok==0)break;
  }

if(x1<A&&A<x2&&y1<B&&B<y2)return 0;
return 1;
}
void solve()
{
scanf("%d%d",&A,&B);
scanf("%d",&n);
for(int i=1;i<=n;i++) 
  {
  scanf("%d%d%d%d",&a,&b,&c,&d);
  if(a==c)
    {
    if(b>d)swap(b,d);
    if(b<0&&0<d)
      {
      x.PB(MP(a,MP(b,0)));
      x.PB(MP(a,MP(d,0)));      
      }
    else
      {
      x.PB(MP(a,MP(b,d)));
      }
    }
  
  else 
    {
    if(a>c)swap(a,c);
    if(a<0&&0<c)
      {
      y.PB(MP(b,MP(a,0)));
      y.PB(MP(b,MP(c,0)));      
      }
    else
      {
      y.PB(MP(b,MP(a,c)));
      }
    }
  
  
  }
int poc=0;
int kon=1e6+1;
int sr=0;
while(sr!=(poc+kon)/2)
  {
  sr=(poc+kon)/2;
  if(check(sr))poc=sr;
  else kon=sr;
  }
while(check(sr+1))sr++;
while(check(sr)==0)sr--;
printf("%d\n",sr);
}
int main()
{
solve();
}
