#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<queue>
#include<unordered_map>
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<int>
#define LL long long
#define MP make_pair
#define LD long double
#define PB push_back
#define ALL(V) V.begin(),V.end()
using namespace std;
int n,a,b,w,s,k,c,d,e;
VI V[100004];
bool uz[100004];
int C=1e9;
VI X;
int dfs(int skad,int pop)
{
int sum=0;
int mx=0,a;
for(int i=0;i<V[skad].size();i++)
  {
  if(V[skad][i]==pop)continue;
  a=dfs(V[skad][i],skad);
  mx=max(mx,a);
  sum+=a;
  }
sum++;
mx=max(mx,n-sum);
if(mx<C)
  {
  C=mx;
  X.clear();
  }
if(mx==C)
  {
  X.PB(skad);
  }
return sum;
}
priority_queue < PII > q;
vector< PII >  pod[100004];
void dfs2(int skad,int pop,int odl,int podd)
{
if(odl!=0)pod[podd].PB(MP(odl,skad));

for(int i=0;i<V[skad].size();i++)
  {
  if(V[skad][i]==pop)continue;
  if(odl==0)dfs2(V[skad][i],skad,odl+1,V[skad][i]);
  else dfs2(V[skad][i],skad,odl+1,podd);
  }

}
pair < LL,VI > licz(int Z)
{
while(q.size())q.pop();
for(int i=1;i<=n;i++)
  {
  pod[i].clear();
  
  }
dfs2(Z,0,0,0);
//printf("MAM %d %d\n",C.f,C.s);
int popodl=0;

LL wyn=0;
VI out;

for(int i=1;i<=n;i++)
  {
  if(pod[i].size()==0)continue; 
  q.push(MP(pod[i].size(),i));
  sort(ALL(pod[i]));
  }
out.PB(Z);
PII pop;
for(int i=2;i<=n;i++)
  {
  if(q.size()==0){puts("DUPA");continue;}
  PII x=q.top();
  q.pop();
  if(i!=2&&pop.f!=0)q.push(pop);
  x.f--;
//  cout<<pod[x.s].back().f<<" "<<pod[x.s].back().s<<endl;
  out.PB(pod[x.s].back().s);
  wyn+=2*pod[x.s].back().f;
  pod[x.s].pop_back();
  pop=x;
  }
return MP(wyn,out);
}
main()
{
scanf("%d",&n);
for(int i=1;i<n;i++)
  {
  scanf("%d%d",&a,&b);
  V[a].PB(b);
  V[b].PB(a);
  }
dfs(1,0);
pair<LL,VI> x,y;
x=licz(X[0]);
if(X.size()>1)y=licz(X[1]);
if(x.f<y.f)swap(x,y);

printf("%lld\n",x.f);
for(int i=0;i<n;i++)printf("%d ",x.s[i]);
}