#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<tr1/unordered_map>
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<int>
#define LL long long
#define MP make_pair
#define LD long double
#define PB push_back
#define ALL(V) V.begin(),V.end()
#define VPII vector< PII >
#define size(V) ((int)V.size())
using namespace std;
int n,a,b,m;
const int MXN=3093;

char in[MXN][MXN];
int dp[MXN][MXN];
PII prawox[MXN][MXN];
PII dolx[MXN][MXN];
int X=10;

int ID=1;
PII find(int a,int b)
{
ID++;
PII x=MP(a,b);
PII y=MP(a,b);
x.f++;
y.s++;

while(x!=y)
   {
//   cout<<x.f<<" "<<x.s<<" "<<y.f<<" "<<y.s<<endl;
   
   if(prawox[x.f][x.s]!=MP(0,0)&&dolx[y.f][y.s]!=MP(0,0))
      {
      if(prawox[x.f][x.s].f>dolx[y.f][y.s].f&&prawox[x.f][x.s].s<dolx[y.f][y.s].s)
         {
//         puts("A");
         x=prawox[x.f][x.s];
         y=dolx[y.f][y.s];

         continue;
         }
      }

   if(in[x.f][x.s]=='M'||in[x.f][x.s]=='O')
      x.s++;
   else
      x.f++;

   if(in[y.f][y.s]=='R'||in[y.f][y.s]=='O')
      y.f++;
   else
      y.s++;

   }
return x;
}
void prawo(PII x)
{
PII poc=x;
for(int i=0;i<X;i++)
   {
   if(in[x.f][x.s]=='M'||in[x.f][x.s]=='O')
      x.s++;
   else
      x.f++; 
   }
if(x.f>n||x.s>m)x=MP(n,m);
prawox[poc.f][poc.s]=x;

}
void dol(PII y)
{
PII poc=y;
for(int i=0;i<X;i++)
   {
   if(in[y.f][y.s]=='R'||in[y.f][y.s]=='O')
      y.f++;
   else
      y.s++;
   }
if(y.f>n||y.s>m)y=MP(n,m);
dolx[poc.f][poc.s]=y;
}

void solve()
{
scanf("%d%d",&m,&n);
while(X*X*X*(X+6)<n*m)X++;

for(int i=1;i<=n;i++)
   {
   for(int j=1;j<=m;j++)
      {
      while(in[i][j]<33)in[i][j]=getchar_unlocked();
      }
   }
for(int i=1;i<=n;i++)
   {
   for(int j=1;j<=m;j++)
      {
      prawo(MP(i,j));
      dol(MP(i,j));
      }
   }
for(int i=n;i>=1;i--)
   {
   for(int j=m;j>=1;j--)
      {
      if(in[i][j]=='X')dp[i][j]=1;
      if(in[i][j]=='M')dp[i][j]=dp[i][j+1]+1;
      if(in[i][j]=='R')dp[i][j]=dp[i+1][j]+1;
      if(in[i][j]!='O')continue;
      
      PII x=find(i,j);
      dp[i][j]=dp[i+1][j]+dp[i][j+1]-dp[x.f][x.s]+1;
      }
   }
ios_base::sync_with_stdio(0);
for(int i=1;i<=n;i++)
   {
   for(int j=1;j<=m;j++)
      {
      cout<<dp[i][j]<<" ";
      }
   cout<<endl;
   }  


}
main()
{
solve();
}
