#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
#include<tr1/unordered_map>
#include<queue>
#include<cstdlib>
#include<list>
#include<set>
#include<map>
#include<cmath>
#define MP make_pair
#define PB push_back
#define s second
#define f first
#define PII pair<int,int>
#define VPII vector< PII > 
#define VI vector <int>
#define abs(a) max((a),-(a))
#define LL long long
#define LD long double
#define ALL(x) x.begin(),x.end()
#define PU putchar_unlocked
#define GU getchar_unlocked
using namespace std;
int a,b,c,d,N;
LL dp[71][71][71];
int MOD=1e9+7;
LL cachepot[71][71];
LL pot(LL a,LL n)
{
if(n==0)return 1;
if(n%2==0)
	{
	LL b=pot(a,n/2);
	return b*b%MOD;
	}
else
	{
	return (pot(a,n-1)*a)%MOD;		
	}
}
LL s[71];
LL inv[71];
void pre()
{
s[0]=1;
for(int i=1;i<=70;i++)
	{
	s[i]=s[i-1]*i%MOD;
	inv[i]=pot(s[i],MOD-2);
	}
}
LL C(int n,int k)
{
return ((s[n]*inv[k])%MOD*inv[n-k])%MOD;
}
void calc(int n,int p,int h)
{
if(n-p<1)return;
for(int s=1;s<=N;s++)
	{
	dp[n][p][h]+=dp[n-p][s][h-1]*C(n,p)%MOD*cachepot[s][p];
	dp[n][p][h]%=MOD;
	}

}
void solve()
{
pre();
scanf("%d",&N);
dp[1][1][0]=1;

for(int i=1;i<=N;i++)
	for(int j=1;j<=N;j++)
		cachepot[i][j]=pot(i,j);

for(int i=1;i<=N;i++)
	for(int j=1;j<=N;j++)
		for(int h=1;h<=N;h++)
			calc(i,j,h);

LL res=0;
for(int i=1;i<N;i++)
	{
	for(int j=1;j<=N;j++)res+=dp[N][j][i];
	printf("%lld ",res%MOD);
	}

}
int main()
{
solve();
}