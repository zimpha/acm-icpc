#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<tr1/unordered_map>
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<int>
#define LL long long
#define MP make_pair
#define LD long double
#define PB push_back
#define ALL(V) V.begin(),V.end()
using namespace std;
int n,a,b,r0,r1,l1,l0;
pair< PII, PII > in[100004];
map<int,int> M;
int ID=1;
   const int BASE=1<<18;
class drzewo
   {

   int t[BASE*2];
   public:
   void insert(int a,int b)
      {
      a+=BASE;
      t[a]=max(t[a],b);
      a/=2;
      while(a)
         {
         t[a]=max(t[a*2],t[a*2+1]);
         a/=2;
         }
      }
   int query(int a,int b)
      {
      a+=BASE-1;
      b+=BASE+1;
      int ret=0;
      while(a/2!=b/2)
         {
         if(a%2==0)ret=max(ret,t[a+1]);
         if(b%2==1)ret=max(ret,t[b-1]);
         a/=2;
         b/=2;
         }
      return ret;
      }
   } X;
int t[100004];
void solve()
{
scanf("%d",&n);
vector< PII > V;
for(int i=1;i<=n;i++)
   {
   scanf("%d%d%d%d",&in[i].f.f,&in[i].f.s,&in[i].s.f,&in[i].s.s);
   M[in[i].s.f]=1;
   M[in[i].s.s]=1;
   V.PB(MP(in[i].f.f,i));
   V.PB(MP(in[i].f.s,-i));
   }
for(map<int,int>::iterator it=M.begin();it!=M.end();it++)
   {
   it->s=ID++;
   }
for(int i=1;i<=n;i++)
   {
   in[i].s.f=M[in[i].s.f];
   in[i].s.s=M[in[i].s.s];
   }
sort(ALL(V));
for(int i=0;i<V.size();i++)
   {
   a=V[i].s;
   //cout<<a<<endl;
   if(a>0)
      {
      t[a]=X.query(1,in[a].s.f);
  //    cout<<"   "<<t[a]<<endl;
      }
   else
      {
      X.insert(in[-a].s.s,t[-a]+1); 
      
      }
   }
printf("%d\n",X.query(1,ID));
}
main()
{
solve();
}
