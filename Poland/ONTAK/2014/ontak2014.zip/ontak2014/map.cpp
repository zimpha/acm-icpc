#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
#include<tr1/unordered_map>
#include<queue>
#include<cstdlib>
#include<list>
#include<set>
#include<map>
#include<cmath>
#define MP make_pair
#define PB push_back
#define s second
#define f first
#define PII pair<int,int>
#define VPII vector< PII > 
#define VI vector <int>
#define abs(a) max((a),-(a))
#define LL long long
#define LD long double
#define ALL(x) x.begin(),x.end()
#define PU putchar_unlocked
#define GU getchar_unlocked
#define size(V) ((int)V.size())
using namespace std;
int n,m,a,b,c,d;
int pion[1003][1004];
int poz[1004][1004];
bool mogepion(int i1,int j1,int i2,int j2,int j)
{
if(j2==j)return 0;

for(int i=i1;i<=i2;i++)
	if(pion[i][j]!=pion[i1][j])return 0;
for(int i=i1;i<=i2;i++)
	{
	int a=j-1;
	int b=j+1;
	while(j1<=a&&b<j2)
		{
		if(pion[i][a]==pion[i][b])return 0;
		a--;
		b++;
		}
	}
for(int i=i1;i<i2;i++)
	{
	int a=j;
	int b=j+1;
	while(j1<=a&&b<=j2)
		{
		if(poz[i][a]==poz[i][b])return 0;
		a--;
		b++;
		}
	}
return 1;
}
bool mogepoz(int i1,int j1,int i2,int j2,int i)
{
if(i==i2)return 0;
for(int j=j1;j<=j2;j++)
	if(poz[i][j]!=poz[i][j1])return 0;
for(int j=j1;j<=j2;j++)
	{
	int a=i-1;
	int b=i+1;
	while(i1<=a&&b<i2)
		{
		if(poz[a][j]==poz[b][j])return 0;
		a--;
		b++;
		}
	}
for(int j=j1;j<j2;j++)
	{
	int a=i;
	int b=i+1;
	while(i1<=a&&b<=i2)
		{
		if(pion[a][j]==pion[b][j])return 0;
		a--;
		b++;
		}
	}
return 1;
}
int ok=0;
VI out;
void rek(int i1,int j1,int i2,int j2)
{
if(i1==i2&&j1==j2)
	{
	ok=1;
	return;
	}
int ia=i1;
int ib=i2-1;
int ja=j1;
int jb=j2-1;
int i,j;

while(1)
  {
  if(ib<ia&&jb<ja)break;
  if(ib-ia>jb-ja)
    {
    if(rand()%2==0)
      {
      i=ia;
      ia++;
      }
    else
      {
      i=ib;
      ib--;
      }
	  
	  if(mogepoz(i1,j1,i2,j2,i))
	    {
	    out.PB(i);
	    if(i2-i-1<i-i1)rek(i1,j1,i,j2);
	    else rek(i+1,j1,i2,j2);
      return;
	    }

    }
  else
    {
    if(rand()%2==0)
      {
      j=ja;
      ja++;
      }
    else
      {
      j=jb;
      jb--;
      }
     if(mogepion(i1,j1,i2,j2,j))
		  {
		  out.PB(-j);
		  if(j2-j-1<j-j1)rek(i1,j1,i2,j);
		  else rek(i1,j+1,i2,j2);
		  return;
		  } 
      
      
    }
  }

}
void solve()
{
scanf("%d%d",&n,&m);
for(int i=1;i<=n;i++)
	for(int j=1;j<m;j++)
		scanf(" %c",&pion[i][j]);

for(int i=1;i<n;i++)
	for(int j=1;j<=m;j++)
		scanf(" %c",&poz[i][j]);

rek(1,1,n,m);

if(ok==0)
	{
	puts("NIE");
	return;
	}
else
	{
	puts("TAK");
	cout<<size(out)<<endl;
	for(int i=0;i<size(out);i++)
		{
		if(out[i]<0)printf("| %d\n",-out[i]);
		else printf("- %d\n",out[i]);
		}
	}
}
int main()
{
solve();
}
