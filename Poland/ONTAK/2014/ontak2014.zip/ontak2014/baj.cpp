#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<unordered_map>
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<int>
#define LL long long
#define MP make_pair
#define LD long double
#define PB push_back
#define ALL(V) V.begin(),V.end()
using namespace std;
int n,a,b,w,s,k,c,d,e,z;
LL od1don(LL n)
{
return n*(n+1)/2;
}
LL przedzial(int a,int b)
{
///cout<<a<<" "<<b<<endl;
if(n/a!=n/b)
  {
//  puts("NIE");
  exit(1);
  }
int c=n/a;
LL x=od1don(b)-od1don(a-1);
return x*c;
}
void solve()
{
LL wyn=0;
scanf("%d",&n);
for(int i=1;i*i<=n;i++)
  {
  wyn+=przedzial(i,i);
  if(n/i==i)continue;
  wyn+=przedzial(n/(i+1)+1,n/i);
  }
printf("%lld\n",((LL)n*n)-wyn);
}
main()
{
scanf("%d",&z);
while(z--)solve();

}