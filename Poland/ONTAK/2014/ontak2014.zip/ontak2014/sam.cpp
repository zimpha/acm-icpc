#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<unordered_map>
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<int>
#define LL long long
#define MP make_pair
#define LD long double
#define PB push_back
#define ALL(V) V.begin(),V.end()
using namespace std;
int n,a,b,w,s,k,c,d,e;
main()
{
scanf("%d",&n);
for(int i=1;i<=n;i++)
  {
  scanf("%d",&a);
  b=b^a;
  }
cout<<b<<endl;
}
