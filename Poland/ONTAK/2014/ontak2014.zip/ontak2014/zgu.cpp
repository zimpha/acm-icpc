#include<cstdio>
#include<algorithm>
#include<map>
#include<vector>
#include<algorithm>
#include<iostream>
#define MP make_pair
#define PB push_back
#define f first
#define s second
#define PII pair<int,int>
#define ALL(V) V.begin(),V.end()
using namespace std;
vector< pair< PII ,int> > out;
int odl[304][304];
int n,a,b,c;
void add(int a,int b,int cost)
{
for(int i=1;i<=n;i++)
	{
	odl[a][b]=min(odl[a][b],odl[a][i]+odl[i][b]);
	}
	
if(odl[a][b]==cost)return;
out.PB(MP(MP(a,b),cost));
odl[a][b]=cost;
for(int i=1;i<=n;i++)
	{
	odl[a][i]=min(odl[a][i],odl[a][b]+odl[b][i]);
	}
for(int i=1;i<=n;i++)
	{
	odl[i][b]=min(odl[i][b],odl[i][a]+odl[a][b]);
	}
}

int najk[304][304];

void solve()
{
scanf("%d",&n);
vector< pair< int , PII > > V;
for(int i=1;i<=n;i++)
	{
	for(int j=1;j<=n;j++)
		{
		scanf("%d",&najk[i][j]);
		if(najk[i][j]>0)V.PB(MP(najk[i][j],MP(i,j)));
		}
	}
sort(ALL(V));
for(int i=1;i<=n;i++)
	{
	for(int j=1;j<=n;j++)
		{
		odl[i][j]=1e9+1;
		if(i==j)odl[i][j]=0;
		}
	}
for(int i=0;i<V.size();i++)
	{
	a=V[i].f;
	b=V[i].s.f;
	c=V[i].s.s;
	add(b,c,a);
	}
sort(ALL(out));
printf("%d\n",out.size());
for(int i=0;i<out.size();i++)
	{
	printf("%d %d %d\n",out[i].f.f,out[i].f.s,out[i].s);
	}
return;
for(int i=1;i<=n;i++)
	{
	for(int j=1;j<=n;j++)
		{
		cout<<odl[i][j]<<" ";
		}
	puts("");
	}
}
int main()
{
solve();
}
