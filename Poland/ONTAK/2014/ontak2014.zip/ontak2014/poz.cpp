#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<tr1/unordered_map>
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<int>
#define LL long long
#define MP make_pair
#define LD long double
#define PB push_back
#define ALL(V) V.begin(),V.end()
using namespace std;
int n,a,b;
LL l=1237;
LL hasz[1239];
int t[1239];
int jest[1239];
LL sum;
int wyn;
bool x[1236][1258];

tr1::unordered_map <LL,int> M;


void go(LL l,LL MOD)
{
hasz[0]=1;
for(int i=1;i<=n;i++)
  {
  hasz[i]=(hasz[i-1]*l)%MOD;
  }
M.clear();

for(int i=1;i<=n;i++)
  {
  for(int j=1;j<=n;j++)jest[j]=0;
  sum=0;
  for(int j=i;j<=n;j++)
    {
    if(jest[t[j]])continue;
    else jest[t[j]]++;
    sum+=hasz[t[j]];
    sum%=MOD;
    if(M[sum]==0)
      {
      x[i][j]=1;
      M[sum]=1;
      }
    }
  }

}
int main()
{
scanf("%d",&n);
for(int i=1;i<=n;i++)
  {
  scanf("%d",&t[i]);
  }
go(l,1e15+7);
go(9091,1e14+13);

for(int i=1;i<=n;i++)
  for(int j=i;j<=n;j++)
    wyn+=x[i][j];
printf("%d\n",wyn);
}
