#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<cmath>
#define int LL
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<LL>
#define LL long long
#define MP make_pair
#define LD double
#define PB push_back
#define ALL(V) V.begin(),V.end()
#define abs(x) max((x),-(x))
#define PDD pair<LD,LD> 
#define VPII vector< PII > 
#define size(V) ((int)V.size())
using namespace std;
LL n,a,b,w,s,k,c,d,e,z;
VI licz(VI V)
{
if(size(V)==0)return VI();

VI even,odd,ret;
for(int i=0;i<size(V);i++)
  {
  if(V[i]%2==0)even.PB(V[i]/2);
  else odd.PB(V[i]);
  }
LL mi=1e18;

for(int i=0;i<size(odd);i++)mi=min(mi,odd[i]);
for(int i=0;i<size(odd);i++)
  {
  odd[i]-=mi;
  if(odd[i]!=0)even.PB(odd[i]/2);
  }
 
ret=licz(even);
for(int i=0;i<size(ret);i++)ret[i]*=2;
if(size(odd))ret.PB(mi);
return ret;
}
void solve()
{
scanf("%lld",&n);
VI V;
for(int i=1;i<=n;i++)
  {
  scanf("%lld",&a);
  V.PB(a);
  }
V=licz(V);
printf("TAK\n%lld\n",size(V));
for(int i=0;i<size(V);i++)printf("%lld ",V[i]);
puts("");
}
main()
{
scanf("%lld",&z);
while(z--)solve();
}
