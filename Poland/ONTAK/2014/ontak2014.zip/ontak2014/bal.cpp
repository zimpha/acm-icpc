#include<cstdio>
#include<algorithm>
#include<map>
#include<vector>
#include<algorithm>
#include<iostream>
#include<queue>
#define MP make_pair
#define PB push_back
#define f first
#define s second
#define PII pair<int,int>
#define ALL(V) V.begin(),V.end()
using namespace std;
int a,b,n;
PII x,y,z;
void solve()
{
priority_queue< PII >q;
vector< int > out;
scanf("%d",&n);
map<int,int> M;
for(int i=1;i<=n;i++)
		{
		scanf("%d",&a);
		M[a]++;
		}
for(map<int,int>::iterator it=M.begin();it!=M.end();it++)
	{
	q.push(MP(it->s,it->f));
	}
while(q.size()>2)
	{
	x=q.top();
	q.pop();
	y=q.top();
	q.pop();
	z=q.top();
	q.pop();	
	x.f--;y.f--;z.f--;
	if(x.s<y.s)swap(x,y);
	if(x.s<z.s)swap(x,z);
	if(y.s<z.s)swap(y,z);
	if(x.f!=0)q.push(x);
	if(y.f!=0)q.push(y);
	if(z.f!=0)q.push(z);
	out.PB(x.s);
	out.PB(y.s);
	out.PB(z.s);
	}
	
printf("%d\n", (int)out.size()/3);
		for(int i=0; i<(int)out.size(); i+=3)
		{
			printf("%d %d %d\n", out[i], out[i+1], out[i+2]);
			
		}

}
int main()
{
	int z;
scanf("%d",&z);
while(z--)solve();
}
