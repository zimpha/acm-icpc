#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<unordered_map>
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<int>
#define LL long long
#define MP make_pair
#define LD long double
#define PB push_back
#define ALL(V) V.begin(),V.end()
using namespace std;
int n,a,b,w,s,k,c,d,e,z,m;
vector < pair< pair<LD,LD> , pair<LD,LD> > > V;

map<PII,int> M;
unordered_map<LL,bool> X;
int l=3;
LL L=9090909090909101LL;
int det(LD a1,LD b1,LD a2,LD b2,LD a3,LD b3)
{
LD x=(a1*b2+b1*a3+a2*b3)-(a3*b2+b3*a1+a2*b1);
if(x>0)return 1;
else return 2;
}

LL hasz(int a,int b)
{
LL res=0;
int c=0;
for(int i=0;i<V.size();i++)
  {
  c=det(V[i].f.f,V[i].f.s,V[i].s.f,V[i].s.s,a,b);

  res=res*l+c;
  while(res>=L)res-=L;
  }
return res;

}
void solve()
{
M.clear();
V.clear();
X.clear();
scanf("%d%d",&n,&m);
int plaszczyzn=1;
int b0=0;
int a0=0;
for(int i=1;i<=n;i++)
  {
  
  scanf("%d%d%d",&a,&b,&c);
  if(a==0&&b==0)continue;
  if(a!=0&&b!=0)
    {int a1,b1;
    d=__gcd(a,b);
    a1=a/d;
    b1=b/d;
    
    plaszczyzn+=i-M[MP(a1,b1)];
    M[MP(a1,b1)]++;
    V.PB(MP(MP(1,((double)-a*1.0-c)/b),MP(2,((double)-a*2.0-c)/b)));
    }
  if(b==0)
    {
    plaszczyzn+=i-b0;
    V.PB(MP(MP((double)-c/((double)a),1),MP((double)-c/((double)a),2)));
    b0++;
    }
  if(a==0)
    { 
    plaszczyzn+=i-a0;
    V.PB(MP(MP(1,(double)-c/((double)b)),MP(2,(double)-c/((double)b))));
    a0++;
    }
  }
;
int rozne=0;
for(int i=1;i<=m;i++)
  {
  scanf("%d%d",&a,&b);
  LL x=hasz(a,b);
  if(X[x]==0)
    {
    rozne++;
    X[x]=1;
    }
  }
  
  
printf(rozne==plaszczyzn?"TAK\n":"NIE\n");
//cout<<plaszczyzn<<" "<<rozne<<endl;
}
main()
{
scanf("%d",&z);
while(z--)solve();

}
