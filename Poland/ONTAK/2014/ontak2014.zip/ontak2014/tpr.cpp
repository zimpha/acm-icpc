#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<tr1/unordered_map>
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<int>
#define LL long long
#define MP make_pair
#define LD long double
#define PB push_back
#define ALL(V) V.begin(),V.end()
using namespace std;
int n,m,a,b,c,q;
char ch;
const int MAGIC=320;//rozmiar grupy
const int MXN=101204;
int t[MXN][MXN/MAGIC+10];
PII x[MXN];
bool active[MXN];
int ILL;

void calc(int a,int b)//1,400 400,800
{
int X=a/MAGIC;
//for(int i=1;i<=n;i++)printf("%d ",t[i][X]);puts("");
for(int i=b-1;i>=a;i--)
  {
  t[x[i].f][X]=x[i].f;
  t[x[i].s][X]=x[i].s;
//  cout<<x[i].f<<" "<<x[i].s<<endl;
  }

for(int i=b-1;i>=a;i--)
  {
  if(active[i]==0)continue;
  swap(t[x[i].f][X],t[x[i].s][X]);
  }
//for(int i=1;i<=n;i++)printf("%d ",t[i][X]);puts("");
}
int go(int a)
{
for(int i=0;i<ILL;i++)
  {
  if(t[a][i]==0)continue;

  a=t[a][i];
  }
return a;
}
void solve()
{
scanf("%d%d",&n,&m);
ILL=m/MAGIC+3;

for(int i=1;i<=m;i++)
  {
  scanf("%d%d",&x[i].f,&x[i].s); 
  active[i]=1;
  }
for(int i=1;i<=n;i++)
  {
  for(int j=0;j<ILL;j++)
    {
    t[i][j]=i;
    }
  }
for(int i=1;i<ILL;i++)calc(max(1,(i-1)*MAGIC),i*MAGIC);


scanf("%d",&q);
int d=0;
while(q--)
  {
  scanf(" %c%d",&ch,&a);
  if(ch=='C')
    {
    active[a]=((int)active[a]+1)%2; 
    calc(max(1,a-a%MAGIC),a-a%MAGIC+MAGIC);
    }
  else
    {
    d=go(1+(d+a)%n);
    printf("%d\n",d);
    }
  }
}
main()
{
solve();
}
