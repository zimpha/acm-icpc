#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<int>
#define LL long long
#define MP make_pair
#define LD long double
#define PB push_back
#define ALL(V) V.begin(),V.end()
using namespace std;
int n,a,b,k;
int t[100004];
int poct[100004];
void obroc(int a,int b)
{
while(a<b)
  {
  swap(t[a],t[b]);
  a++;
  b--;
  }
}
bool juz()
  {
  for(int i=1;i<=n;i++)if(t[i]!=i)return 0;
  return 1;
  }
VI V;

void rek(VI ter)
{

for(int i=1;i<=n;i++)
  for(int j=i;j<=n;j++)
    {
    ter.PB(i);ter.PB(j);
    rek(ter);
    ter.pop_back();
    ter.pop_back();
    }
}

VI k1()
   {  
   VI x;
   int a=1;
   while(a==t[a])a++;
   if(a==n+1)
     {
     x.PB(1);
     x.PB(1);
     return x;
     }
   int b=n;
   while(b==t[b])b--;
   obroc(a,b);
   if(juz()==0)
     {
     obroc(a,b);
     return VI();
     }
   obroc(a,b);
   x.PB(a);
   x.PB(b);
   return x;
   }
VI k2()
{
VI V;
V.PB(1);
for(int i=2;i<=n;i++)
   {
    if(abs(t[i]-t[i-1])>1)
       {
       if(i!=n)V.PB(i);
       if(i-1!=1)V.PB(i-1);
       }
   }

V.PB(n);
if(V.size()>10)return VI();
sort(ALL(V));

for(int i=0;i<V.size();i++)
  {
  for(int j=i;j<V.size();j++)
    {
    obroc(V[i],V[j]);
    VI x=k1();
    obroc(V[i],V[j]);
    if(x.size()==2)
      {
      x.PB(V[i]);
      x.PB(V[j]);
      return x;
      }
    }
  }
return VI();
}
VI k3()
{
for(int i=0;i<V.size();i++)
  {
  for(int j=i;j<V.size();j++)
    {
    obroc(V[i],V[j]);
    VI x=k2();
    obroc(V[i],V[j]);
    if(x.size()==4)
      {
      x.PB(V[i]);
      x.PB(V[j]);
      return x;
      }
    }
  }
return VI();
}
main()
{
scanf("%d%d",&n,&k);
for(int i=1;i<=n;i++)
  {
  scanf("%d",&t[i]);
  poct[i]=t[i];
   if(i>1&&abs(t[i]-t[i-1])>1)
    {
    V.PB(i);
    V.PB(i-1);
    }
  }
V.PB(1);
V.PB(n);
sort(ALL(V));
if(V.size()>14)
   {
   puts("NIE");
   return 0;
   }
if(k==0)
   {
   if(juz()){printf("TAK");return 0;}
   else puts("NIE");
   return 0;
   }
if(k==1)
  {
  VI x=k1();
  if(x.size()==2)printf("TAK\n%d %d\n",x[0],x[1]);
  else puts("NIE");
  }
if(k==2)
  {
  VI x=k2();
  if(x.size()==4)printf("TAK\n%d %d\n%d %d\n",x[2],x[3],x[0],x[1]);
  else puts("NIE");
  
  }
if(k==3)
  {
  VI x=k3();
  if(x.size()==6)printf("TAK\n%d %d\n%d %d\n%d %d\n",x[4],x[5],x[2],x[3],x[0],x[1]);
  else puts("NIE");  
  }

}
