#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<cmath>
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<int>
#define LL long long
#define MP make_pair
#define LD long double
#define PB push_back
#define ALL(V) V.begin(),V.end()
using namespace std;
int n,a,b,w,s,k,c,d,e;
main()
{
VI ans; 
scanf("%d",&n);
if(n==0)ans={5,2,5,3};
if(n==1)
  {
  ans={1,6,7,10,7,15,1,2,1,3};
  }
if(n==2)
  {
  ans={7,3,5*3,2*7,1,7,2,25,1,5};
  }
if(n==3)
  {
  ans={19,7,11*7,2*19,13*7,3*19,1,19,2*5,11,3*5,13};
  }
if(n==4)
  {

  for(int i=6;i>=1;i--)
    {
    ans.PB(pow(7,i));
    ans.PB(pow(2*3*5,i));
    }
  for(int i=6;i>=1;i--)
    {
    ans.PB(pow(7,i));
    ans.PB(pow(2*3,i));
    }
  for(int i=6;i>=1;i--)
    {
    ans.PB(pow(7,i));
    ans.PB(pow(2*5,i));
    }
  for(int i=6;i>=1;i--)
    {
    ans.PB(pow(7,i));
    ans.PB(pow(3*5,i));
    }
  for(int i=6;i>=1;i--)
    {
    ans.PB(pow(1,i));
    ans.PB(pow(2,i));
    }
  for(int i=6;i>=1;i--)
    {
    ans.PB(pow(1,i));
    ans.PB(pow(3,i));
    }
  for(int i=6;i>=1;i--)
    {
    ans.PB(pow(1,i));
    ans.PB(pow(5,i));
    }
  ans.PB(1);
  ans.PB(11);
  }
if(n==5)
  {
  ans={2*23*31,17, 29,31,  11*31,2*5*29,  5,11*29, 5,11, 3*5*5*17,2*23,  3*5*17,2,1,5,1,23,1,29};
  }
printf("%d\n",ans.size()/2);
for(int i=0;i<ans.size();i+=2)printf("%d %d\n",ans[i],ans[i+1]);
}
