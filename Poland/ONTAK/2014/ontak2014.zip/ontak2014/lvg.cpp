#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<map>
#include<unordered_map>
#define PII pair<int,int>
#define f first
#define s second
#define VI vector<int>
#define LL long long
#define MP make_pair
#define LD long double
#define PB push_back
#define ALL(V) V.begin(),V.end()
using namespace std;
int n,a,b,w,s,k,c,d,e,z;
bool dp[203][203];
vector< PII > V[203][203];
int t[204];
int x=0;
void dfs(int a,int b)
{
if(dp[a][b])return;
dp[a][b]=1;
x++;
for(int i=0;i<V[a][b].size();i++)
  {
  dfs(V[a][b][i].f,V[a][b][i].s);
  }

}
void solve()
{
scanf("%d%d",&n,&k);

for(int i=0;i<n;i++)
    {
    for(int j=0;j<n;j++)
      {
      dp[i][j]=0;
      V[i][j].clear();
      }
    }


for(int i=1;i<=k;i++)
  {
  for(int i=0;i<n;i++)
    {
    scanf("%d",&t[i]);
    }
  for(int i=0;i<n;i++)
    {
    for(int j=0;j<n;j++)
      {
      dp[i][j]=0;
      V[t[i]][t[j]].PB(MP(i,j));
      }
    }
  }
x=0;
dfs(0,0);
if(x==n*n)
  {
  puts("TAK");
  }
else puts("NIE");
}
main()
{
scanf("%d",&z);
while(z--)solve();
}
