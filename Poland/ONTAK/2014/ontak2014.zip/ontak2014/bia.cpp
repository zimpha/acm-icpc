#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
#include<tr1/unordered_map>
#include<queue>
#include<cstdlib>
#include<list>
#include<set>
#include<map>
#include<cmath>
#define MP make_pair
#define PB push_back
#define s second
#define f first
#define PII pair<int,int>
#define VPII vector< PII > 
#define VI vector <int>
#define abs(a) max((a),-(a))
#define LL long long
#define LD long double
#define ALL(x) x.begin(),x.end()
#define PU putchar_unlocked
#define GU getchar_unlocked
using namespace std;
int k;
LL n,m;
PII in[21];
LL comp(LL a,LL b,LL c,LL d)
{
//printf("%d %d %d %d %d\n",a,b,c,d,a*b*(m-c+1)*(n-d+1));
return a*b*(m-c+1)*(n-d+1);
}
void solve()
{
scanf("%lld%lld%d",&m,&n,&k);
for(int i=0;i<k;i++)
	scanf("%d%d",&in[i].f,&in[i].s);
LL res=0;
for(int i=1;i<(1<<k);i++)
	{
	int mxy=0,mxx=0,mix=1e9,miy=1e9;
	int e=0;
	for(int j=0;j<k;j++)
		{
		if((1<<j)&i)
			{
			e++;
			mxy=max(mxy,in[j].s);
			mxx=max(mxx,in[j].f);
			mix=min(mix,in[j].f);
			miy=min(miy,in[j].s);
			}
		}
	LL X=comp(mix,miy,mxx,mxy);
	if(e%2==1)res+=X;
	else res-=X;
	}
printf("%lld\n",n*(n+1)/2*m*(m+1)/2-res);
}
int main()
{
solve();
}